#********************************************************************
#* Copyright (c) 2018 Veritas Technologies LLC. All rights reserved *
#********************************************************************

This package contains an update to the NetBackup mappings files. The 
external_robotics.txt and external_types.txt files are used by the 
NetBackup Enterprise Media Manager database to interact with tape drive, 
tape library, and virtual tape drive / library devices. They are also 
used by the Device Configuration Wizard to automatically configure new 
devices.

The presence of a device in the file "external_types.txt" does not indicate, 
expressed or implied, support of the device on the target NetBackup/Enterprise
Media Manager platform. Refer to the NetBackup Hardware and Cloud Storage 
Compatibility List (HCL), found below in the Related Documents section, 
for a current list of supported devices.  

These files work with NetBackup 7.7.x and 8.x.x releases.


***********************************
Appliance Installation Instructions
***********************************

Note:  To load NetBackup device mappings files onto a NetBackup Appliance
running in a Master Server role, contact Veritas Support and ask the
representative to refer to Article 000107907.


*********************************
Windows Installation Instructions
*********************************

These instructions assume that NetBackup is installed in the default 
location of C:\Program Files\Veritas\.  If NetBackup is installed in a 
different location, substitute that path for C:\Program Files\Veritas\ 
in the instructions below:

1. Download and extract the new mappings file to a temporary folder.  
This will create three files in the temporary location:

    * Readme.txt (this file) 
    * external_types.txt
    * external_robotics.txt

2. Copy the external_types.txt file from the temporary location to 
C:\Program Files\Veritas\NetBackup\var\global\ on the Master/EMM Server. 

    (For NetBackup High Availability environments, copy the file to the 
    shared disk.)

3. Copy the external_robotics.txt file from the temporary location to 
C:\Program Files\Veritas\NetBackup\var\global\ on the Master/EMM Server,
each Media Server that controls a robot, and each Media Server from
which robot inventories will be run.
 
    (For NetBackup High Availability environments, copy the file to the 
	shared disk.)


4. Bring up a command window using Start -> Run -> Type "cmd".  Enter the 
following commands in that command window.

5. Update the NetBackup Enterprise Media Manager database with the new 
device mappings version. This only needs to be done once and must be run 
from the Master/EMM Server.  Use the command format below: 

    C:\Program Files\Veritas\Volmgr\bin\tpext -loadEMM
    C:\Program Files\Veritas\Volmgr\bin\tpext -get_dev_mappings

6. Restart Device Manager (ltid) on each Media Server.  

7. Verify that the version that is now stored in the Enterprise Media Manager 
database is the same as what is in the file stored on the Media Server:

    C:\Program Files\Veritas\volmgr\bin\tpext -get_dev_mappings_ver

**************************************
UNIX / Linux Installation Instructions
**************************************

These instructions assume that NetBackup is installed in the default 
location of /usr/openv/.  If NetBackup is installed in a different location, 
substitute that path for /usr/openv/ in the instructions below:

1. Download and extract the new mappings file package to a temporary directory:

    tar -xvf Mappings_vNNN.tar
	(where NNN is the version of the mappings file contained in the tar file)
 
This will create three files in the temporary location:

    * Readme.txt (this file) 
    * external_types.txt
    * external_robotics.txt

2. Copy the external_types.txt file from the temporary location to 
/usr/openv/var/global on the Master/EMM Server:

    cp /temp_dir/external_types.txt /usr/openv/var/global/

    (For NetBackup High Availability environments, copy the file to the 
    shared disk.)

3. Copy the external_robotics.txt file from the temporary location to /usr/openv/var/global on the Master/EMM Server, each Media Server that controls a robot, and each Media Server from which robot inventories will be run:

  cp /temp_dir/external_robotics.txt /usr/openv/var/global/

 (For NetBackup High Availability environments, copy the file to the shared disk.)

4. Update the NetBackup Enterprise Media Manager database with the new 
device mappings version.  This only needs to be done once and must be run 
from the Master/EMM Server.  Use the command format below: 

    /usr/openv/volmgr/bin/tpext -loadEMM
    /usr/openv/volmgr/bin/tpext -get_dev_mappings

5. Restart Device Manager (ltid) on each Media Server.

6. Verify that the version that is now stored in the Enterprise Media Manager 
database is the same as what is in the file stored on the Media Server:

    /usr/openv/volmgr/bin/tpext -get_dev_mappings_ver

